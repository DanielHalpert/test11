package com.fxcm.api.sample;

import com.fxcm.api.FXConnectLiteSessionFactory;
import com.fxcm.api.IFXConnectLiteSession;
import com.fxcm.api.entity.instrument.Instrument;
import com.fxcm.api.entity.instrument.InstrumentDescriptor;
import com.fxcm.api.entity.login.LoginError;
import com.fxcm.api.entity.messages.data.terminals.ITradingTerminal;
import com.fxcm.api.interfaces.connection.IConnectionStatus;
import com.fxcm.api.interfaces.connection.IConnectionStatusChangeListener;
import com.fxcm.api.interfaces.login.ILoginCallback;
import com.fxcm.api.interfaces.login.IPinCodeSetter;
import com.fxcm.api.interfaces.login.ITradingTerminalSelector;
import com.fxcm.api.interfaces.tradingdata.IDataManagerState;
import com.fxcm.api.interfaces.tradingdata.IDataManagerStateChangeListener;
import com.fxcm.api.service.logger.DefaultLogger;

import java.util.Arrays;
import java.util.Optional;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class AvailableInstruments {
    public static void main(String[] args) {
        checkArgs(args);
        final IFXConnectLiteSession session = FXConnectLiteSessionFactory.create("JavaGetInstrumentsSample");
        final CompletableFuture<Boolean> connectedFuture = new CompletableFuture<>();
        session.subscribeConnectionStatusChange(new ConnectionStatusChangeListener(connectedFuture));
        //session.setLogger(new DefaultLogger());
        session.login(args[0], args[1], args[2], args[3], new LoginCallback());
        connectedFuture.thenRun(() -> {
            session.getInstrumentsManager().subscribeStateChange(new InstrumentsDataManagerStateChangeListener(session));
            session.getInstrumentsManager().refresh();
        });
        final ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);
        scheduledExecutorService.schedule(() -> {
            session.logout();
            System.exit(0);
        }, 5, TimeUnit.SECONDS);
    }

    private static class InstrumentsDataManagerStateChangeListener implements IDataManagerStateChangeListener {
        private IFXConnectLiteSession session;

        public InstrumentsDataManagerStateChangeListener(IFXConnectLiteSession session) {
            this.session = session;
        }

        @Override
        public void onStateChange(IDataManagerState iDataManagerState) {
            if(iDataManagerState.isLoaded()) {
                print_symbols_list(session);
            }
        }
    }

    public static void print_symbols_list(IFXConnectLiteSession session)
    {
        int i;
        final Instrument[] all_instruments = session.getInstrumentsManager().getAllInstruments();
        final Instrument[] subscribed_instruments = session.getInstrumentsManager().getSubscribedInstruments();
        final InstrumentDescriptor[] instruments2 = session.getInstrumentsManager().getAllInstrumentDescriptors();
        int t1 = subscribed_instruments.length;
        int t2 = subscribed_instruments.length;
        System.out.println("All instruments count: " + all_instruments.length);
        for (i=0; i < all_instruments.length; i++)
        {
            System.out.println(all_instruments[i].getSymbol());
        }

        System.out.println("subscribed instruments count: " + subscribed_instruments.length);
        for (i=0; i < subscribed_instruments.length; i++)
        {
            System.out.println(subscribed_instruments[i].getSymbol());
        }
        
        System.out.println("instruments2 count: " + instruments2.length);
        for (i=0; i < instruments2.length; i++)
        {
            System.out.println(instruments2[i].getSymbol());
        }
        
    }
    
    private static class LoginCallback implements ILoginCallback {

        @Override
        public void onLoginError(LoginError loginError) {
            System.out.println("Login error: (" + loginError.getCode() + ") " + loginError.getMessage());
            System.exit(1);
        }

        @Override
        public void onTradingTerminalRequest(ITradingTerminalSelector tradingTerminalSelector, ITradingTerminal[] tradingTerminals) {
            System.out.println("Available trading terminals:");
            for (ITradingTerminal terminal: tradingTerminals) {
                System.out.println(terminal.getSubId());
            }
            System.out.println("Enter terminal name: ");
            Scanner scanner = new Scanner(System.in);
            while(true) {
                String inputString = scanner.nextLine();
                final Optional<ITradingTerminal> terminal = Arrays.stream(tradingTerminals)
                        .filter(t -> t.getSubId().equals(inputString))
                        .findFirst();
                if(terminal.isPresent()) {
                    tradingTerminalSelector.selectTerminal(terminal.get());
                    return;
                }
                System.out.println("Requested terminal not found");
            }
        }

        @Override
        public void onPinCodeRequest(IPinCodeSetter pinCodeSetter) {
            System.out.println("Enter PIN code: ");
            Scanner scanner = new Scanner(System.in);
            String inputString = scanner.nextLine();
            pinCodeSetter.setPinCode(inputString);
        }
    }

    private static class ConnectionStatusChangeListener implements IConnectionStatusChangeListener {
        private final CompletableFuture<Boolean> connectedFuture;

        public ConnectionStatusChangeListener(CompletableFuture<Boolean> connectedFuture) {
            this.connectedFuture = connectedFuture;
        }

        public void onConnectionStatusChange(IConnectionStatus connectionStatus) {
            System.out.println("Connection status changed: " + getStringName(connectionStatus));
            if(connectionStatus.isConnected()) {
                connectedFuture.complete(true);
            }
        }

        private String getStringName(IConnectionStatus connectionStatus) {
            return (connectionStatus.isConnected() ? "Connected" : "") +
                    (connectionStatus.isConnecting() ? "Connecting" : "") +
                    (connectionStatus.isReconnecting() ? "Reconnecting" : "") +
                    (connectionStatus.isDisconnected() ? "Disconnected" : "");
        }
    }

    private static void checkArgs(String[] args) {
        if (args.length < 4) {
            System.out.println("Arguments should be: username password tradeServerUrl connection");
            System.exit(1);
        }
    }
}
